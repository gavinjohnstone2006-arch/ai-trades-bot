# Mobile-Friendly Options (iPhone)

You’ve got two easy paths to control the bot from your phone:

## 1) **Google Colab Controller** (fastest)
- Open the Colab notebook: `colab/AI_Trades_Bot_Controller.ipynb`
- Upload `ai_trades_bot_v2.zip` when prompted
- Tap **Run Once** or **Loop-run** (keeps running while the tab is open)
- Works great for paper mode and quick tests

## 2) **Streamlit Web App** (best iPhone UX)
Deploy the included dashboard so you can visit a URL on your iPhone:

**Streamlit Community Cloud (free):**
1. Push your bot folder + `streamlit/` to a GitHub repo
2. Go to share.streamlit.io → deploy your repo
3. Set secrets (if alerts or live trading): `DISCORD_WEBHOOK_URL`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`
4. Open the site on your phone and tap buttons

**Render/Heroku:**
- Use the included `Procfile`
- Set environment variables and deploy
- Open the public URL on your iPhone

## 3) **Replit or GitHub Codespaces**
- Import repo → `pip install -r requirements.txt`
- Run `streamlit run streamlit/app.py` and open the webview from your phone

## 4) **Always-on VPS (hands-off)**
- Host on a small VPS (Lightsail/DigitalOcean)
- Add a cron job to run `schedule_runner.py`
- Control notifications via Discord/Telegram

### Notes
- iOS can’t run persistent Python bots natively; use cloud (Colab/Streamlit/Replit/VPS).
- Always start in **paper** mode. Live trading = real risk.
